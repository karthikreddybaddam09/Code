import boto3, itertools
import json
from botocore.client import ClientError

def create_groups_from_filtered_ports(my_port_list):
	for a, b in itertools.groupby(enumerate(my_port_list), lambda pair: pair[1] - pair[0]):
		b = list(b)
		yield b[0][1], b[-1][1]

def filter_port_groups(fromport, toport, port_list_to_check):
	my_ports_yes = []
	my_ports_no = []
	for port in range(fromport, toport + 1):
		if port in port_list_to_check:
			my_ports_yes.append(port)
		else:
			my_ports_no.append(port)
	return { 'yes' : list(create_groups_from_filtered_ports(my_ports_yes)), 'no' : list(create_groups_from_filtered_ports(my_ports_no)) }
	

other_ports = ['11','47','50','51','9000', '53', '80', '81', '8080', '8081', '443', '8443','5061', '5269', '1720', '5060', '5062', '10100', '10101', '20100']
skip_ingress_ports = list(range(15000, 21000)) + [ int(i) for i in other_ports]

outbound_ports = ['8','47','50','51','9000', '53', '80', '81', '8080', '8081', '443', '8443','5061', '5269', '1720', '5060', '5062','10100', '10101', '20100']
skip_outgress_ports = list(range(9000,9009)) + list(range(50000,60000)) + [ int(i) for i in outbound_ports]

def handler(event, context):
	my_session = boto3.Session(region_name = 'us-east-1')
	client = my_session.client('ec2')
	regions = [ i['RegionName'] for i in client.describe_regions()['Regions'] ]
	for region in regions:
		my_session = boto3.Session(region_name = region)
		client = my_session.client('ec2')
		response = client.describe_security_groups()['SecurityGroups']
		print("Now running for region %s" % (region))
		for sg in response:
			sgid = sg['GroupId']
			input = sg['IpPermissions']
			output = sg['IpPermissionsEgress']
			for sgVal in input:
				try:
					fromport = sgVal.get('FromPort')
					toport = sgVal.get('ToPort')
					ipranges = [ i['CidrIp'] for i in sgVal['IpRanges']] + [ i['CidrIpv6'] for i in sgVal['Ipv6Ranges']]
					ipprotocol = sgVal['IpProtocol']
					for cidr in ipranges:
						if cidr in [ '0.0.0.0/0', '::/0' ]:
							if cidr == '0.0.0.0/0':
								if not fromport and not toport and ipprotocol == '-1':
									response = client.revoke_security_group_ingress(GroupId=sgid,CidrIp='0.0.0.0/0',IpProtocol=ipprotocol)
									continue
								else:
									filtered_ports = filter_port_groups(fromport, toport, skip_ingress_ports)
									if filtered_ports['no']: response = client.revoke_security_group_ingress(GroupId=sgid,CidrIp='0.0.0.0/0',IpProtocol=ipprotocol,FromPort = fromport,ToPort = toport)
							if cidr == '::/0':
								if not fromport and not toport and ipprotocol == '-1':
									response = client.revoke_security_group_ingress(GroupId=sgid,IpPermissions = [{'Ipv6Ranges' : [ {'CidrIpv6' : '::/0' } ] ,'IpProtocol': ipprotocol}])
									continue
								else:
									filtered_ports = filter_port_groups(fromport, toport, skip_ingress_ports)
									if filtered_ports['no']: response = client.revoke_security_group_ingress(GroupId=sgid,IpPermissions = [{'Ipv6Ranges' : [ {'CidrIpv6' : '::/0' } ] ,'IpProtocol': ipprotocol, 'FromPort' : fromport, 'ToPort' : toport}])
							for fport, tport in filtered_ports.get('yes', []):
								if cidr == '0.0.0.0/0' : client.authorize_security_group_ingress(GroupId=sgid,CidrIp='0.0.0.0/0',IpProtocol=ipprotocol,FromPort = fport,ToPort = tport)
								if cidr == '::/0' : client.authorize_security_group_ingress( GroupId=sgid,IpPermissions = [{'Ipv6Ranges' : [ {'CidrIpv6' : '::/0' } ] ,'IpProtocol': ipprotocol, 'FromPort' : fport, 'ToPort' : tport}])
				except ClientError as e:
					if e.response['Error']['Code'] == 'InvalidPermission.Duplicate' : pass
				except Exception as e:
					print('ERROR : Inbound SG %s (%s) has error %s' % ( sgid, region, str(e)))
			for sgVal in output:
				try:
					fromport = sgVal.get('FromPort')
					toport = sgVal.get('ToPort')
					ipranges = [ i['CidrIp'] for i in sgVal['IpRanges']] + [ i['CidrIpv6'] for i in sgVal['Ipv6Ranges']]
					ipprotocol = sgVal['IpProtocol']
					for cidr in ipranges:
						if cidr in [ '0.0.0.0/0', '::/0' ]:
							if cidr == '0.0.0.0/0':
								if not fromport and not toport and ipprotocol == '-1':
									response = client.revoke_security_group_egress(GroupId=sgid,IpPermissions = [{'IpRanges' : [ {'CidrIp' : '0.0.0.0/0' } ] ,'IpProtocol': ipprotocol}])
									continue
								else:
									filtered_ports = filter_port_groups(fromport, toport, skip_outgress_ports)
									if filtered_ports['no']: response = client.revoke_security_group_egress(GroupId=sgid,IpPermissions = [{'IpRanges' : [ {'CidrIp' : '0.0.0.0/0' } ] ,'IpProtocol': ipprotocol, 'FromPort' : fromport, 'ToPort' : toport}])
							if cidr == '::/0':
								if not fromport and not toport and ipprotocol == '-1':
									response = client.revoke_security_group_egress(GroupId=sgid,IpPermissions = [{'IpRanges' : [ {'CidrIp' : '0.0.0.0/0' } ] ,'IpProtocol': ipprotocol}])
									continue
								else:
									filtered_ports = filter_port_groups(fromport, toport, skip_outgress_ports)
									if filtered_ports['no']: response = client.revoke_security_group_egress(GroupId=sgid,IpPermissions = [{'Ipv6Ranges' : [ {'CidrIpv6' : '::/0' } ] ,'IpProtocol': ipprotocol, 'FromPort' : fromport, 'ToPort' : toport}])
							for fport, tport in filtered_ports.get('yes', []):
								if cidr == '0.0.0.0/0' : client.authorize_security_group_egress(GroupId=sgid,IpPermissions = [{'IpRanges' : [ {'CidrIp' : '8.0.0.0/0' } ] ,'IpProtocol': ipprotocol, 'FromPort' : fromport, 'ToPort' : toport}])
								if cidr == '::/0' : client.authorize_security_group_egress( GroupId=sgid,IpPermissions = [{'Ipv6Ranges' : [ {'CidrIpv6' : '::/0' } ] ,'IpProtocol': ipprotocol, 'FromPort' : fport, 'ToPort' : tport}])
				except ClientError as e:
                                	if e.response['Error']['Code'] == 'InvalidPermission.Duplicate' : pass
				except Exception as e:
					print('ERROR : Outbound SG %s (%s) has error %s' % ( sgid, region, str(e)))
	return True

